#' Raw moment of order r for the Bessel-Exponential distribution
#'
#' Computes the raw moment of order \eqn{r} for a random variable
#' following the Bessel-Exponential (BE) distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#' @param r Order of the raw moment.
#'
#' @return Numeric value corresponding to \eqn{E(Y^r)}.
#' @export
momBE <- function(mu, sigma, r) {
  if (any(!is.finite(mu)) || any(mu <= 0)) {
    stop("mu must contain positive finite values.")
  }
  if (any(!is.finite(sigma)) || any(sigma <= 0)) {
    stop("sigma must contain positive finite values.")
  }
  if (any(!is.finite(r))) {
    stop("r must be finite.")
  }

  mu^r * besselK(2 * mu / sigma, -(1 + r)) / besselK(2 * mu / sigma, -1)
}

#' Mean of the Bessel-Exponential distribution
#'
#' Computes the mean of the Bessel-Exponential (BE) distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to \eqn{E(Y)}.
#' @export
meanBE <- function(mu, sigma) {
  momBE(mu, sigma, 1)
}

#' Variance of the Bessel-Exponential distribution
#'
#' Computes the variance of the Bessel-Exponential (BE) distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to \eqn{Var(Y)}.
#' @export
varBE <- function(mu, sigma) {
  momBE(mu, sigma, 2) - momBE(mu, sigma, 1)^2
}

#' Coefficient of variation of the Bessel-Exponential distribution
#'
#' Computes the coefficient of variation of the Bessel-Exponential (BE)
#' distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to the coefficient of variation.
#' @export
cvaBE <- function(mu, sigma) {
  sqrt(varBE(mu, sigma)) / meanBE(mu, sigma)
}

#' Skewness of the Bessel-Exponential distribution
#'
#' Computes the skewness coefficient of the Bessel-Exponential (BE)
#' distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to the skewness coefficient.
#' @export
skewBE <- function(mu) {
  m1 <- momBE(mu, 1, 1)
  m2 <- momBE(mu, 1, 2)
  m3 <- momBE(mu, 1, 3)

  (m3 - 3 * m1 * m2 + 2 * m1^3) / (m2 - m1^2)^(3/2)
}

#' Kurtosis of the Bessel-Exponential distribution
#'
#' Computes the kurtosis coefficient of the Bessel-Exponential (BE)
#' distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to the kurtosis coefficient.
#' This is the ordinary kurtosis, not the excess kurtosis.
#' @export
kurtBE <- function(mu) {
  m1 <- momBE(mu, 1, 1)
  m2 <- momBE(mu, 1, 2)
  m3 <- momBE(mu, 1, 3)
  m4 <- momBE(mu, 1, 4)

  (m4 - 4 * m1 * m3 + 6 * m1^2 * m2 - 3 * m1^4) / (m2 - m1^2)^2
}

#' Excess kurtosis of the Bessel-Exponential distribution
#'
#' Computes the excess kurtosis (Fisher kurtosis) of the
#' Bessel-Exponential (BE) distribution.
#'
#' @param mu Mode parameter (\eqn{\mu > 0}).
#' @param sigma Scale parameter (\eqn{\sigma > 0}).
#'
#' @return Numeric value corresponding to the excess kurtosis.
#' @export
exkurtBE <- function(mu) {
  kurtBE(mu) - 3
}
