#' Monte Carlo BE MLE across scenarios and sample sizes
#'
#' @param scenarios data.frame with columns: Scenario, mu_true, sigma_true
#' @inheritParams mc_BE_by_n
#' @export
mc_BE_grid <- function(R,
                       scenarios,
                       ns = c(50,100,200,400),
                       seed = 2026,
                       alpha = 0.05,
                       fit_control = list(n_starts = 15)) {

  req <- c("Scenario","mu_true","sigma_true")
  if (!all(req %in% names(scenarios)))
    stop("scenarios must contain columns: Scenario, mu_true, sigma_true")

  ns <- as.integer(ns)

  out <- list()
  k <- 0L

  for (i in seq_len(nrow(scenarios))) {
    for (j in seq_along(ns)) {
      k <- k + 1L
      tmp <- mc_BE_one_setting(
        R = R, n = ns[j],
        mu_true = scenarios$mu_true[i],
        sigma_true = scenarios$sigma_true[i],
        seed = seed + 1000*i + j,   # separa streams por escenario y n
        alpha = alpha,
        fit_control = fit_control,
        return_raw = FALSE
      )
      tmp$Scenario <- scenarios$Scenario[i]
      out[[k]] <- tmp
    }
  }

  res <- do.call(rbind, out)
  res <- res[, c("Scenario","n","mu_true","sigma_true",
                 "Bias_mu","RMSE_mu","Cov95_mu",
                 "Bias_sigma","RMSE_sigma","Cov95_sigma",
                 "Conv_pct")]
  rownames(res) <- NULL
  res
}