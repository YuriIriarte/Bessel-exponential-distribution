#' Monte Carlo performance for BE regression MLE (one setting)
#'
#' @param R Number of Monte Carlo replicates.
#' @param n Sample size.
#' @param scenario List with elements:
#'   beta = true coefficients for the modal submodel,
#'   nu   = true coefficients for the dispersion submodel.
#' @param cov_par List with empirical parameters used to simulate covariates.
#' @param seed Optional integer seed.
#' @param alpha Significance level for Wald CI (default 0.05 => 95% CI).
#' @param fit_control List passed to fitBE_regression
#'   (e.g., list(n_starts = 15, jitter_sd = 0.05)).
#' @param return_raw Logical; if TRUE, returns replicate-level results too.
#'
#' @return If return_raw=FALSE: data.frame summary.
#'         If return_raw=TRUE: list(summary=..., raw=data.frame).
#' @export
mc_BE_reg_one_setting <- function(R, n, scenario, cov_par,
                                  seed = NULL, alpha = 0.05,
                                  fit_control = list(n_starts = 15, jitter_sd = 0.05),
                                  return_raw = FALSE) {

  R <- as.integer(R)
  n <- as.integer(n)

  if (!is.null(seed)) set.seed(as.integer(seed))
  if (!is.finite(R) || R <= 0) stop("R must be a positive integer.")
  if (!is.finite(n) || n <= 0) stop("n must be a positive integer.")
  if (!is.finite(alpha) || alpha <= 0 || alpha >= 1) stop("alpha must be in (0,1).")
  if (!is.list(scenario) || is.null(scenario$beta) || is.null(scenario$nu))
    stop("scenario must be a list containing beta and nu.")
  if (!is.list(cov_par)) stop("cov_par must be a list.")

  z <- stats::qnorm(1 - alpha / 2)

  p_beta <- length(scenario$beta)
  p_nu   <- length(scenario$nu)

  beta_hat <- matrix(NA_real_, nrow = R, ncol = p_beta)
  nu_hat   <- matrix(NA_real_, nrow = R, ncol = p_nu)

  se_beta <- matrix(NA_real_, nrow = R, ncol = p_beta)
  se_nu   <- matrix(NA_real_, nrow = R, ncol = p_nu)

  colnames(beta_hat) <- paste0("beta_", 0:(p_beta - 1))
  colnames(nu_hat)   <- paste0("nu_",   0:(p_nu - 1))
  colnames(se_beta)  <- paste0("se_beta_", 0:(p_beta - 1))
  colnames(se_nu)    <- paste0("se_nu_",   0:(p_nu - 1))

  conv <- rep(0L, R)
  valid <- rep(0L, R)
  logLik <- rep(NA_real_, R)

  fit_call <- function(y, X_mu, X_sigma) {
    args <- c(list(y = y, X_mu = X_mu, X_sigma = X_sigma), fit_control)
    do.call(fitBE_regression, args)
  }

  for (r in seq_len(R)) {

    dat <- tryCatch(
      simulate_BE_regression_data(
        n = n,
        cov_par = cov_par,
        scenario = scenario,
        seed = if (is.null(seed)) NULL else seed + r
      ),
      error = function(e) NULL
    )

    if (is.null(dat)) next

    fit <- tryCatch(
      fit_call(
        y = dat$y,
        X_mu = attr(dat, "X_mu"),
        X_sigma = attr(dat, "X_sigma")
      ),
      error = function(e) NULL
    )

    if (is.null(fit)) next

    conv[r] <- as.integer(isTRUE(fit$convergence == 0))
    logLik[r] <- fit$logLik

    ok <- isTRUE(fit$convergence == 0) &&
      is.finite(fit$logLik) &&
      fit$logLik > -1e+50 &&
      all(is.finite(fit$coefficients_mu)) &&
      all(is.finite(fit$coefficients_sigma))

    if (!ok) next

    valid[r] <- 1L
    beta_hat[r, ] <- fit$coefficients_mu
    nu_hat[r, ]   <- fit$coefficients_sigma

    if (!is.null(fit$se_mu)) se_beta[r, ] <- fit$se_mu
    if (!is.null(fit$se_sigma)) se_nu[r, ] <- fit$se_sigma
  }

  idx <- which(valid == 1L)

  mean_beta <- colMeans(beta_hat[idx, , drop = FALSE], na.rm = TRUE)
  mean_nu   <- colMeans(nu_hat[idx, , drop = FALSE], na.rm = TRUE)

  bias_beta <- mean_beta - scenario$beta
  bias_nu   <- mean_nu - scenario$nu

  rmse_beta <- sqrt(colMeans((sweep(beta_hat[idx, , drop = FALSE], 2, scenario$beta, "-"))^2, na.rm = TRUE))
  rmse_nu   <- sqrt(colMeans((sweep(nu_hat[idx, , drop = FALSE], 2, scenario$nu, "-"))^2, na.rm = TRUE))

  cp_beta <- rep(NA_real_, p_beta)
  cp_nu   <- rep(NA_real_, p_nu)

  for (j in seq_len(p_beta)) {
    cov_idx_j <- idx[is.finite(se_beta[idx, j]) & se_beta[idx, j] > 0]
    cp_beta[j] <- if (length(cov_idx_j) == 0) NA_real_ else {
      mean(
        scenario$beta[j] >= beta_hat[cov_idx_j, j] - z * se_beta[cov_idx_j, j] &
        scenario$beta[j] <= beta_hat[cov_idx_j, j] + z * se_beta[cov_idx_j, j]
      )
    }
  }

  for (j in seq_len(p_nu)) {
    cov_idx_j <- idx[is.finite(se_nu[idx, j]) & se_nu[idx, j] > 0]
    cp_nu[j] <- if (length(cov_idx_j) == 0) NA_real_ else {
      mean(
        scenario$nu[j] >= nu_hat[cov_idx_j, j] - z * se_nu[cov_idx_j, j] &
        scenario$nu[j] <= nu_hat[cov_idx_j, j] + z * se_nu[cov_idx_j, j]
      )
    }
  }

  summary_df <- data.frame(
    R = R,
    n = n,
    Scenario = if (!is.null(scenario$label)) scenario$label else NA_character_,
    Conv_pct = 100 * mean(conv),
    Valid_pct = 100 * mean(valid),
    mean_logLik_valid = mean(logLik[idx], na.rm = TRUE)
  )

  for (j in seq_len(p_beta)) {
    summary_df[[paste0("Bias_beta_", j - 1)]] <- bias_beta[j]
    summary_df[[paste0("RMSE_beta_", j - 1)]] <- rmse_beta[j]
    summary_df[[paste0("Cov95_beta_", j - 1)]] <- cp_beta[j]
  }

  for (j in seq_len(p_nu)) {
    summary_df[[paste0("Bias_nu_", j - 1)]] <- bias_nu[j]
    summary_df[[paste0("RMSE_nu_", j - 1)]] <- rmse_nu[j]
    summary_df[[paste0("Cov95_nu_", j - 1)]] <- cp_nu[j]
  }

  if (!return_raw) return(summary_df)

  raw_df <- data.frame(
    rep = seq_len(R),
    conv = conv,
    valid = valid,
    logLik = logLik
  )

  raw_df <- cbind(
    raw_df,
    as.data.frame(beta_hat),
    as.data.frame(nu_hat),
    as.data.frame(se_beta),
    as.data.frame(se_nu)
  )

  list(summary = summary_df, raw = raw_df)
}
