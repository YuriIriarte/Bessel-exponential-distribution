#' Monte Carlo BE regression MLE across scenarios and sample sizes
#'
#' @param scenarios Named list of scenarios. Each scenario must contain
#'   at least elements beta and nu, and optionally label.
#' @inheritParams mc_BE_reg_by_n
#' @export
mc_BE_reg_grid <- function(R,
                           scenarios,
                           ns = c(50, 100, 200, 400),
                           cov_par,
                           seed = 2026,
                           fit_control = list(n_starts = 15, jitter_sd = 0.05)) {

  if (!is.list(scenarios) || length(scenarios) == 0)
    stop("scenarios must be a non-empty list.")

  ns <- as.integer(ns)

  out <- list()
  k <- 0L

  sc_names <- names(scenarios)
  if (is.null(sc_names)) sc_names <- paste0("S", seq_along(scenarios))

  for (i in seq_along(scenarios)) {
    sc <- scenarios[[i]]

    if (is.null(sc$beta) || is.null(sc$nu))
      stop("Each scenario must contain beta and nu.")

    for (j in seq_along(ns)) {
      k <- k + 1L

      tmp <- mc_BE_reg_one_setting(
        R = R,
        n = ns[j],
        scenario = sc,
        cov_par = cov_par,
        seed = seed + 1000 * i + j,
        fit_control = fit_control,
        return_raw = FALSE
      )

      tmp$Scenario <- sc_names[i]
      out[[k]] <- tmp
    }
  }

  res <- do.call(rbind, out)

  # put key columns first
  first_cols <- c("Scenario", "n", "R", "Conv_pct", "Valid_pct", "mean_logLik_valid")
  other_cols <- setdiff(names(res), first_cols)
  res <- res[, c(first_cols, other_cols)]

  rownames(res) <- NULL
  res
}