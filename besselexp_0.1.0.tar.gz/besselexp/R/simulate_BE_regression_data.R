# ============================================================
# Simulate one BE regression dataset with covariates
# ============================================================

#' Simulate one dataset from the BE regression model
#'
#' @param n Sample size.
#' @param cov_par List with empirical parameters used to simulate covariates.
#' @param scenario List with elements beta and nu containing the true coefficients.
#' @param seed Optional integer seed.
#'
#' @return A data.frame containing the simulated response and covariates.
#'         The design matrices are stored as attributes "X_mu" and "X_sigma".
#' @export
simulate_BE_regression_data <- function(n, cov_par, scenario, seed = NULL) {

  n <- as.integer(n)
  if (!is.finite(n) || n <= 0) stop("n must be a positive integer.")
  if (!is.list(cov_par)) stop("cov_par must be a list.")
  if (!is.list(scenario)) stop("scenario must be a list with elements beta and nu.")
  if (is.null(scenario$beta) || is.null(scenario$nu))
    stop("scenario must contain elements beta and nu.")

  if (!is.null(seed)) set.seed(as.integer(seed))

  gamma_moments_to_shape_rate <- function(mean, sd) {
    shape <- mean^2 / sd^2
    rate  <- mean / sd^2
    list(shape = shape, rate = rate)
  }

  bmi_par <- gamma_moments_to_shape_rate(cov_par$bmi_mean, cov_par$bmi_sd)
  bca_par <- gamma_moments_to_shape_rate(cov_par$bca_mean, cov_par$bca_sd)

  dat <- data.frame(
    age = rnorm(n, mean = cov_par$age_mean, sd = cov_par$age_sd),
    bmi = rgamma(n, shape = bmi_par$shape, rate = bmi_par$rate),
    bca = rgamma(n, shape = bca_par$shape, rate = bca_par$rate),
    sex = rbinom(n, size = 1, prob = cov_par$sex_prob),
    uvi = rbinom(n, size = 1, prob = cov_par$uvi_prob)
  )

  # standardize / center
  dat$age_z <- (dat$age - cov_par$age_mean) / cov_par$age_sd
  dat$bmi_z <- (dat$bmi - cov_par$bmi_mean) / cov_par$bmi_sd
  dat$bca_z <- (dat$bca - cov_par$bca_mean) / cov_par$bca_sd
  dat$sex_c <- dat$sex - cov_par$sex_prob
  dat$uvi_c <- dat$uvi - cov_par$uvi_prob

  X_mu <- stats::model.matrix(~ age_z + bmi_z + bca_z + sex_c + uvi_c, data = dat)
  X_sigma <- X_mu

  eta_mu    <- as.numeric(X_mu %*% scenario$beta)
  eta_sigma <- as.numeric(X_sigma %*% scenario$nu)

  mu_i    <- exp(eta_mu)
  sigma_i <- exp(eta_sigma)

  if (any(!is.finite(mu_i)) || any(mu_i <= 0)) stop("Invalid values in mu_i.")
  if (any(!is.finite(sigma_i)) || any(sigma_i <= 0)) stop("Invalid values in sigma_i.")

  y <- numeric(n)
  for (i in seq_len(n)) {
    y[i] <- rBE(1, mu = mu_i[i], sigma = sigma_i[i])
  }

  dat$y <- y
  dat$mu_true_i <- mu_i
  dat$sigma_true_i <- sigma_i

  attr(dat, "X_mu") <- X_mu
  attr(dat, "X_sigma") <- X_sigma

  dat
}