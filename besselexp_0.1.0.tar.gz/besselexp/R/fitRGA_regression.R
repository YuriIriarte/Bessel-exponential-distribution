#' Fit a reparameterized Gamma regression model by maximum likelihood
#'
#' Fits a regression model based on the reparameterized Gamma distribution
#' using maximum likelihood estimation. The model allows covariates to affect
#' both the mean parameter \eqn{\mu} and the shape-like parameter
#' \eqn{\sigma} through log links:
#' \deqn{
#' \mu_i = \exp(\mathbf{x}_{\mu i}^\top \boldsymbol{\beta}),
#' \qquad
#' \sigma_i = \exp(\mathbf{x}_{\sigma i}^\top \boldsymbol{\nu}).
#' }
#'
#' The optimization is carried out with \code{\link[stats]{optim}} under
#' a multi-start strategy. If user-supplied starting values are provided,
#' they are included among the candidate starting points. The solution with
#' the smallest negative log-likelihood is retained.
#'
#' @param y Numeric vector of positive responses.
#' @param X_mu Design matrix for the mean submodel.
#' @param X_sigma Design matrix for the shape/dispersion submodel. By default,
#'   \code{X_sigma = X_mu}.
#' @param start Optional numeric vector of starting values for the optimizer.
#'   Its length must be equal to \code{ncol(X_mu) + ncol(X_sigma)}.
#' @param method Optimization method passed to \code{\link[stats]{optim}}.
#'   Default is \code{"BFGS"}.
#' @param n_starts Number of candidate starting values used in the multi-start
#'   strategy. Default is \code{5}.
#' @param jitter_sd Standard deviation of the Gaussian perturbation used to
#'   jitter the automatic starting values. Default is \code{0.15}.
#' @param seed Optional integer seed for reproducibility of the multi-start
#'   perturbations.
#' @param keep_all_fits Logical; if \code{TRUE}, all optimization attempts,
#'   starting values, and convergence codes are stored in the returned object.
#'
#' @return An object of class \code{"RGA_regression"} containing:
#' \describe{
#'   \item{\code{coefficients_mu}}{Estimated regression coefficients for the
#'   mean submodel.}
#'   \item{\code{coefficients_sigma}}{Estimated regression coefficients for the
#'   shape/dispersion submodel.}
#'   \item{\code{se_mu}}{Approximate standard errors for the mean submodel
#'   coefficients.}
#'   \item{\code{se_sigma}}{Approximate standard errors for the
#'   shape/dispersion submodel coefficients.}
#'   \item{\code{z_mu}}{Wald \(z\)-statistics for the mean submodel coefficients.}
#'   \item{\code{z_sigma}}{Wald \(z\)-statistics for the shape/dispersion
#'   submodel coefficients.}
#'   \item{\code{p_mu}}{Two-sided Wald \(p\)-values for the mean submodel
#'   coefficients.}
#'   \item{\code{p_sigma}}{Two-sided Wald \(p\)-values for the shape/dispersion
#'   submodel coefficients.}
#'   \item{\code{fitted_mu}}{Fitted values of \eqn{\mu_i}.}
#'   \item{\code{fitted_sigma}}{Fitted values of \eqn{\sigma_i}.}
#'   \item{\code{y}}{Response vector used in the fit.}
#'   \item{\code{X_mu}}{Design matrix for the mean submodel.}
#'   \item{\code{X_sigma}}{Design matrix for the shape/dispersion submodel.}
#'   \item{\code{logLik}}{Maximized log-likelihood value.}
#'   \item{\code{AIC}}{Akaike Information Criterion.}
#'   \item{\code{BIC}}{Bayesian Information Criterion.}
#'   \item{\code{convergence}}{Convergence code returned by \code{optim}.}
#'   \item{\code{vcov}}{Estimated variance-covariance matrix based on the
#'   inverse Hessian.}
#'   \item{\code{best_start}}{Starting vector associated with the retained fit.}
#'   \item{\code{best_start_index}}{Index of the retained starting vector.}
#'   \item{\code{all_objective_values}}{Objective-function values from all
#'   optimization attempts.}
#'   \item{\code{all_fits}}{List of all optimization objects, returned only if
#'   \code{keep_all_fits = TRUE}.}
#'   \item{\code{all_starts}}{List of all starting vectors, returned only if
#'   \code{keep_all_fits = TRUE}.}
#'   \item{\code{all_convergences}}{Convergence codes from all optimization
#'   attempts, returned only if \code{keep_all_fits = TRUE}.}
#' }
#'
#' @details
#' This function is intended as a benchmark regression model to compare with
#' the proposed BE regression model. The maximization is performed under a
#' multi-start strategy to reduce sensitivity to local optima.
#'
#' Standard errors, Wald statistics, and \(p\)-values are computed from the
#' inverse Hessian matrix returned by the selected optimization run. If the
#' Hessian is singular or numerically unstable, some standard errors may be
#' returned as \code{NA} or \code{NaN}.
#'
#' @examples
#' set.seed(123)
#'
#' n <- 40
#' x1 <- rnorm(n)
#' x2 <- rbinom(n, 1, 0.5)
#' x3 <- runif(n)
#'
#' X_mu <- model.matrix(~ x1 + x2 + x3)
#' X_sigma <- model.matrix(~ x1 + x2)
#'
#' beta <- c(1.0, 0.3, -0.2, 0.1)
#' nu <- c(1.2, 0.2, 0.1)
#'
#' mu <- exp(drop(X_mu %*% beta))
#' sigma <- exp(drop(X_sigma %*% nu))
#'
#' y <- stats::rgamma(n, shape = sigma, rate = sigma / mu)
#'
#' fit <- fitRGA_regression(y, X_mu = X_mu, X_sigma = X_sigma)
#' summary(fit)
#'
#' @seealso \code{\link{dRGA}}, \code{\link{pRGA}}
#' @export
fitRGA_regression <- function(y, X_mu, X_sigma = X_mu,
                              start = NULL,
                              method = "BFGS",
                              n_starts = 5,
                              jitter_sd = 0.15,
                              seed = NULL,
                              keep_all_fits = FALSE) {

  y <- as.numeric(y)

  if (any(!is.finite(y))) stop("Response must be finite.")
  if (any(y <= 0)) stop("Response must be positive.")

  X_mu <- as.matrix(X_mu)
  X_sigma <- as.matrix(X_sigma)

  n <- length(y)
  p_mu <- ncol(X_mu)
  p_sigma <- ncol(X_sigma)

  if (nrow(X_mu) != n || nrow(X_sigma) != n) {
    stop("X_mu and X_sigma must have the same number of rows as y.")
  }

  if (!is.null(seed)) set.seed(seed)

  # ---------------------------------
  # Negative log-likelihood
  # ---------------------------------
  nll <- function(par) {

    beta <- par[1:p_mu]
    gamma <- par[(p_mu + 1):(p_mu + p_sigma)]

    eta_mu <- drop(X_mu %*% beta)
    eta_sigma <- drop(X_sigma %*% gamma)

    mu <- exp(eta_mu)
    sigma <- exp(eta_sigma)

    if (any(!is.finite(mu)) || any(!is.finite(sigma))) return(1e100)
    if (any(mu <= 0) || any(sigma <= 0)) return(1e100)

    ll <- tryCatch(
      dRGA(y, mu = mu, sigma = sigma, log = TRUE),
      error = function(e) rep(NA_real_, length(y))
    )

    if (any(!is.finite(ll))) return(1e100)

    -sum(ll)
  }

  # ---------------------------------
  # Automatic starting values
  # ---------------------------------
  start_auto <- c(
    c(log(mean(y)), rep(0, p_mu - 1)),
    c(log(var(y) / mean(y)^2), rep(0, p_sigma - 1))
  )

  starts <- list()

  if (!is.null(start)) {
    if (length(start) != (p_mu + p_sigma)) {
      stop("Length of 'start' must be equal to ncol(X_mu) + ncol(X_sigma).")
    }
    starts[[1]] <- as.numeric(start)
  }

  starts[[length(starts) + 1]] <- start_auto

  if (n_starts > 1) {
    for (j in seq_len(n_starts - 1)) {
      starts[[length(starts) + 1]] <- start_auto + stats::rnorm(length(start_auto), 0, jitter_sd)
    }
  }

  starts <- unique(lapply(starts, function(z) round(z, 10)))

  # ---------------------------------
  # Multi-start optimization
  # ---------------------------------
  fit_list <- vector("list", length(starts))
  obj_values <- rep(Inf, length(starts))
  convergences <- rep(NA_integer_, length(starts))

  for (j in seq_along(starts)) {

    fit_j <- tryCatch(
      stats::optim(
        par = starts[[j]],
        fn = nll,
        method = method,
        hessian = TRUE
      ),
      error = function(e) NULL
    )

    fit_list[[j]] <- fit_j

    if (!is.null(fit_j)) {
      obj_values[j] <- fit_j$value
      convergences[j] <- fit_j$convergence
    }
  }

  valid <- which(is.finite(obj_values))

  if (length(valid) == 0) {
    stop("All optimization attempts failed.")
  }

  best_idx <- valid[which.min(obj_values[valid])]
  fit <- fit_list[[best_idx]]

  # ---------------------------------
  # Extract estimates
  # ---------------------------------
  par_hat <- fit$par

  beta_hat <- par_hat[1:p_mu]
  gamma_hat <- par_hat[(p_mu + 1):(p_mu + p_sigma)]

  names(beta_hat) <- paste0("beta_", 0:(p_mu - 1))
  names(gamma_hat) <- paste0("nu_", 0:(p_sigma - 1))

  # ---------------------------------
  # Variance-covariance matrix
  # ---------------------------------
  vcov <- tryCatch(
    solve(fit$hessian),
    error = function(e) matrix(NA_real_, length(par_hat), length(par_hat))
  )

  se <- suppressWarnings(sqrt(diag(vcov)))

  se_beta <- se[1:p_mu]
  se_gamma <- se[(p_mu + 1):(p_mu + p_sigma)]

  names(se_beta) <- names(beta_hat)
  names(se_gamma) <- names(gamma_hat)

  # ---------------------------------
  # Wald statistics
  # ---------------------------------
  z_beta <- beta_hat / se_beta
  z_gamma <- gamma_hat / se_gamma

  p_beta <- 2 * (1 - stats::pnorm(abs(z_beta)))
  p_gamma <- 2 * (1 - stats::pnorm(abs(z_gamma)))

  names(z_beta) <- names(beta_hat)
  names(z_gamma) <- names(gamma_hat)

  names(p_beta) <- names(beta_hat)
  names(p_gamma) <- names(gamma_hat)

  # ---------------------------------
  # Fitted values
  # ---------------------------------
  mu_hat <- exp(drop(X_mu %*% beta_hat))
  sigma_hat <- exp(drop(X_sigma %*% gamma_hat))

  # ---------------------------------
  # Information criteria
  # ---------------------------------
  logLik <- -fit$value
  k <- length(par_hat)

  AIC <- -2 * logLik + 2 * k
  BIC <- -2 * logLik + log(n) * k

  # ---------------------------------
  # Output
  # ---------------------------------
  out <- list(
    coefficients_mu = beta_hat,
    coefficients_sigma = gamma_hat,

    se_mu = se_beta,
    se_sigma = se_gamma,

    z_mu = z_beta,
    z_sigma = z_gamma,

    p_mu = p_beta,
    p_sigma = p_gamma,

    fitted_mu = mu_hat,
    fitted_sigma = sigma_hat,

    y = y,
    X_mu = X_mu,
    X_sigma = X_sigma,

    logLik = logLik,
    AIC = AIC,
    BIC = BIC,

    convergence = fit$convergence,
    vcov = vcov,

    best_start = starts[[best_idx]],
    best_start_index = best_idx,
    all_objective_values = obj_values
  )

  if (keep_all_fits) {
    out$all_fits <- fit_list
    out$all_starts <- starts
    out$all_convergences <- convergences
  }

  class(out) <- "RGA_regression"
  out
}