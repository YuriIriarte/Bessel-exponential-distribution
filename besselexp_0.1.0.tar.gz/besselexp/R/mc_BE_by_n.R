#' Monte Carlo BE MLE across sample sizes (one scenario)
#'
#' @param ns Integer vector of sample sizes.
#' @inheritParams mc_BE_one_setting
#' @export
mc_BE_by_n <- function(R, ns = c(50, 100, 200, 400),
                       mu_true, sigma_true,
                       seed = NULL, alpha = 0.05,
                       fit_control = list(n_starts = 15)) {

  ns <- as.integer(ns)
  if (any(!is.finite(ns)) || any(ns <= 0)) stop("ns must be positive integers.")

  # reproducible but different streams per n
  if (is.null(seed)) seed <- sample.int(.Machine$integer.max, 1)

  out <- lapply(seq_along(ns), function(j) {
    mc_BE_one_setting(
      R = R, n = ns[j],
      mu_true = mu_true, sigma_true = sigma_true,
      seed = seed + j,
      alpha = alpha,
      fit_control = fit_control,
      return_raw = FALSE
    )
  })

  do.call(rbind, out)
}