#' MLE for Gamma distribution (shape, scale)
#' @param x Numeric vector (x > 0).
#' @param start Named numeric vector with elements shape and scale.
#' @return A list with elements par, se, logLik, AIC, BIC, convergence.
#' @export
fitGamma_mle <- function(x, start = c(shape = NA_real_, scale = NA_real_)){

  x <- as.numeric(x)

  if (any(!is.finite(x))) stop("x must be finite.")
  if (any(x <= 0)) stop("All observations must be positive.")

  n <- length(x)

  if (is.na(start["shape"])) start["shape"] <- 1
  if (is.na(start["scale"])) start["scale"] <- mean(x)

  nll <- function(par){

    shape <- par[1]
    scale <- par[2]

    if(shape <= 0 || scale <= 0) return(1e100)

    ll <- dgamma(x, shape = shape, scale = scale, log = TRUE)

    if(any(!is.finite(ll))) return(1e100)

    -sum(ll)
  }

  fit <- optim(
    par = start,
    fn = nll,
    method = "L-BFGS-B",
    lower = c(1e-8, 1e-8), 
    upper = c(Inf, Inf),
    hessian = TRUE
  )

  shape_hat <- unname(fit$par[1])
  scale_hat <- unname(fit$par[2])

  logLik <- -fit$value

  k <- 2
  AIC <- -2*logLik + 2*k
  BIC <- -2*logLik + log(n)*k

  vcov <- solve(fit$hessian)

  se <- c(
    shape = sqrt(vcov[1,1]),
    scale = sqrt(vcov[2,2])
  )

  list(
    par = c(shape = shape_hat, scale = scale_hat),
    se = se,
    logLik = logLik,
    AIC = AIC,
    BIC = BIC,
    convergence = fit$convergence
  )
}
