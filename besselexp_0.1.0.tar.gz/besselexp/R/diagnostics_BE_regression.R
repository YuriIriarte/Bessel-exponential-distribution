#' Diagnostic tests for BE regression models
#'
#' Performs goodness-of-fit tests using randomized quantile residuals and
#' generalized Cox-Snell residuals from a fitted Bessel-Exponential (BE)
#' regression model.
#'
#' @param object An object of class \code{"BE_regression"} returned by
#'   \code{\link{fitBE_regression}}.
#' @param y Optional response vector. If omitted, the response stored in
#'   \code{object$y} is used.
#' @param digits Number of digits for rounding results.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return A data frame with columns \code{Residual}, \code{Test},
#'   \code{Statistic}, and \code{p.value}, summarizing the diagnostic tests.
#'
#' @details
#' The function applies Anderson-Darling and Cramér-von Mises tests to
#' randomized quantile residuals and generalized Cox-Snell residuals.
#' Under adequate model specification, quantile residuals should follow
#' approximately a standard normal distribution, while Cox-Snell residuals
#' should follow approximately an exponential distribution with rate 1.
#'
#' @examples
#' \dontrun{
#' fit <- fitBE_regression(y, X_mu, X_sigma)
#' diagnostics_BE_regression(fit)
#' }
#'
#' @seealso \code{\link{fitBE_regression}}, \code{\link{residuals.BE_regression}}
#' @export
diagnostics_BE_regression <- function(object,
                                      y = NULL,
                                      digits = 4,
                                      ...) {

  res <- residuals(object, type = "all", y = y)

  ad_q <- goftest::ad.test(res$quantile, "pnorm", mean = 0, sd = 1)
  cvm_q <- goftest::cvm.test(res$quantile, "pnorm", mean = 0, sd = 1)

  ad_cs <- goftest::ad.test(res$coxsnell, "pexp", rate = 1)
  cvm_cs <- goftest::cvm.test(res$coxsnell, "pexp", rate = 1)

  tab <- data.frame(
    Residual = c("Quantile", "Quantile", "Cox-Snell", "Cox-Snell"),
    Test = c("Anderson-Darling", "Cramer-von Mises",
             "Anderson-Darling", "Cramer-von Mises"),
    Statistic = c(ad_q$statistic, cvm_q$statistic,
                  ad_cs$statistic, cvm_cs$statistic),
    p.value = c(ad_q$p.value, cvm_q$p.value,
                ad_cs$p.value, cvm_cs$p.value),
    stringsAsFactors = FALSE
  )

  tab$Statistic <- round(tab$Statistic, digits)
  tab$p.value <- round(tab$p.value, digits)

  tab
}