#' MLE for the Bessel-Exponential (BE) distribution (mode mu, scale sigma)
#'
#' Uses multi-start optimization and keeps the solution with the smallest
#' negative log-likelihood (largest log-likelihood). Standard errors are
#' computed from the observed information when available; otherwise NA.
#'
#' @param x Numeric vector (x > 0).
#' @param start Named numeric vector with elements mu and sigma (optional).
#' @param n_starts Integer; number of starting points (>= 1). Default 7.
#' @param method Optimization method (default "L-BFGS-B").
#' @param lower Lower bounds for (mu, sigma) on natural scale.
#' @param upper Upper bounds for (mu, sigma) on natural scale.
#' @param keep_fits Logical; if TRUE, return all attempted fits.
#'
#' @return A list with elements par, se, logLik, AIC, BIC, convergence,
#'         n_starts_tried, n_starts_ok, and optionally fits.
#' @export
fitBE_mle <- function(x,
                      start = c(mu = NA_real_, sigma = NA_real_),
                      n_starts = 7L,
                      method = "L-BFGS-B",
                      lower = c(mu = 1e-8, sigma = 1e-8),
                      upper = c(mu = Inf,  sigma = Inf),
                      keep_fits = FALSE) {

  x <- as.numeric(x)
  if (any(!is.finite(x))) stop("x must be finite.")
  if (any(x <= 0)) stop("All observations must be positive.")
  n <- length(x)

  # --- Default "central" start (good in practice for your BE parametrization)
  if (is.na(start["mu"]))    start["mu"] <- stats::median(x)
  if (is.na(start["sigma"])) start["sigma"] <- stats::sd(x)

  # --- Negative log-likelihood in log-parameter space (enforces positivity)
  nll <- function(eta) {
    mu <- exp(eta[1])
    sigma <- exp(eta[2])
    -sum(dBE(x, mu = mu, sigma = sigma, log = TRUE))
  }

  # --- Build multi-start set around (mu0, s0)
  mu0 <- unname(start["mu"])
  s0  <- unname(start["sigma"])

  # Basic, deterministic grid of starts (you can enlarge if you want)
  base_starts <- rbind(
    c(mu0,        s0),
    c(0.8 * mu0,  s0),
    c(1.2 * mu0,  s0),
    c(mu0,        0.8 * s0),
    c(mu0,        1.2 * s0),
    c(0.8 * mu0,  1.2 * s0),
    c(1.2 * mu0,  0.8 * s0)
  )

  # If user requests more starts than the grid, add mild random jitters
  n_starts <- as.integer(n_starts)
  if (!is.finite(n_starts) || n_starts < 1L) stop("n_starts must be >= 1.")
  starts <- base_starts
  if (n_starts > nrow(base_starts)) {
    extra <- n_starts - nrow(base_starts)
    # lognormal jitter around (mu0, s0) with small dispersion
    jit_mu <- mu0 * exp(stats::rnorm(extra, mean = 0, sd = 0.25))
    jit_s  <- s0  * exp(stats::rnorm(extra, mean = 0, sd = 0.25))
    starts <- rbind(starts, cbind(jit_mu, jit_s))
  }
  starts <- starts[seq_len(min(n_starts, nrow(starts))), , drop = FALSE]
  colnames(starts) <- c("mu", "sigma")

  # --- Optimize from each start, keep best (smallest nll)
  lower_eta <- log(c(lower["mu"], lower["sigma"]))
  upper_eta <- log(c(upper["mu"], upper["sigma"]))

  best_fit <- NULL
  best_val <- Inf
  all_fits <- vector("list", length = nrow(starts))
  n_ok <- 0L

  for (j in seq_len(nrow(starts))) {

    start_j <- starts[j, ]
    # Guard against pathological starts
    start_j[1] <- max(start_j[1], lower["mu"])
    start_j[2] <- max(start_j[2], lower["sigma"])
    eta0 <- log(as.numeric(start_j))

    fit_j <- tryCatch(
      stats::optim(
        par = eta0,
        fn = nll,
        method = method,
        lower = lower_eta,
        upper = upper_eta,
        hessian = TRUE
      ),
      error = function(e) NULL
    )

    all_fits[[j]] <- fit_j

    if (!is.null(fit_j) && is.finite(fit_j$value)) {
      n_ok <- n_ok + 1L
      if (fit_j$value < best_val) {
        best_val <- fit_j$value
        best_fit <- fit_j
      }
    }
  }

  if (is.null(best_fit)) {
    # No successful optimization
    out <- list(
      par = c(mu = NA_real_, sigma = NA_real_),
      se  = c(mu = NA_real_, sigma = NA_real_),
      logLik = NA_real_,
      AIC = NA_real_,
      BIC = NA_real_,
      convergence = 1L,
      n_starts_tried = nrow(starts),
      n_starts_ok = 0L
    )
    if (keep_fits) out$fits <- all_fits
    class(out) <- "fitBE_mle"
    return(out)
  }

  # --- Best solution
  eta_hat <- best_fit$par
  mu_hat <- exp(eta_hat[1])
  sigma_hat <- exp(eta_hat[2])

  logLik <- -best_fit$value
  k <- 2L
  AIC <- -2 * logLik + 2 * k
  BIC <- -2 * logLik + log(n) * k

  # --- Robust SE from observed information (in eta-space)
  vcov_eta <- tryCatch(solve(best_fit$hessian), error = function(e) NULL)

  se <- c(mu = NA_real_, sigma = NA_real_)
  if (!is.null(vcov_eta)) {
    vcov_eta <- 0.5 * (vcov_eta + t(vcov_eta))  # numeric symmetry
    v1 <- vcov_eta[1, 1]
    v2 <- vcov_eta[2, 2]
    if (is.finite(v1) && v1 > 0) se["mu"]    <- mu_hat    * sqrt(v1)  # delta for exp()
    if (is.finite(v2) && v2 > 0) se["sigma"] <- sigma_hat * sqrt(v2)
  }

  out <- list(
    par = c(mu = mu_hat, sigma = sigma_hat),
    se  = se,
    logLik = logLik,
    AIC = AIC,
    BIC = BIC,
    convergence = best_fit$convergence,
    n_starts_tried = nrow(starts),
    n_starts_ok = n_ok
  )
  if (keep_fits) out$fits <- all_fits

  class(out) <- "fitBE_mle"
  out
}