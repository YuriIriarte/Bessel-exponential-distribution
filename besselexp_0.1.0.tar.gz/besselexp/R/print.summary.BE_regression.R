#' Print method for BE regression summaries
#'
#' @param x An object of class \code{"summary.BE_regression"}.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return The input object is returned invisibly.
#'
#' @method print summary.BE_regression
#' @export
print.summary.BE_regression <- function(x, ...) {

  cat("\nSummary of BE regression model\n")
  cat("---------------------------------\n")
  cat("Log-likelihood:", x$logLik, "\n")
  cat("AIC:", x$AIC, "\n")
  cat("BIC:", x$BIC, "\n")
  cat("Convergence code:", x$convergence, "\n\n")

  print(x$coefficients_table, row.names = FALSE)

  invisible(x)
}