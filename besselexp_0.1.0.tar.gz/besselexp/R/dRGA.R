#' Density of the reparameterized Gamma distribution
#'
#' Computes the density of a Gamma distribution parameterized in terms of
#' the mean \eqn{\mu > 0} and a positive shape-related parameter
#' \eqn{\sigma > 0}.
#'
#' Under this parameterization, the usual Gamma parameters are
#' \deqn{
#' \alpha = \sigma, \qquad \lambda = \sigma/\mu,
#' }
#' where \eqn{\alpha} is the shape parameter and \eqn{\lambda} is the rate.
#'
#' Consequently, the mean of the distribution is
#' \deqn{
#' E(Y) = \mu.
#' }
#'
#' @param x Numeric vector of positive values.
#' @param mu Numeric vector of positive means.
#' @param sigma Numeric vector of positive shape-like parameters.
#' @param log Logical; if \code{TRUE}, the log-density is returned.
#'
#' @return A numeric vector with the density (or log-density) values.
#'
#' @details
#' The density is
#' \deqn{
#' f(y \mid \mu,\sigma)=
#' \frac{(\sigma/\mu)^{\sigma}}{\Gamma(\sigma)}
#' y^{\sigma-1}\exp\left(-\frac{\sigma}{\mu}y\right), \qquad y>0.
#' }
#'
#' This reparameterization is commonly used in regression modeling
#' because the parameter \eqn{\mu} corresponds directly to the mean.
#'
#' @examples
#' dRGA(1, mu = 2, sigma = 3)
#' dRGA(c(1, 2, 3), mu = 2, sigma = 3)
#' dRGA(1, mu = 2, sigma = 3, log = TRUE)
#'
#' x <- seq(0.01, 10, length.out = 100)
#' plot(x, dRGA(x, mu = 2, sigma = 3), type = "l",
#'      ylab = "Density", xlab = "x")
#'
#' @seealso \code{\link{pRGA}}, \code{\link{fitRGA_regression}},
#'   \code{\link[stats]{dgamma}}
#' @export
dRGA <- function(x, mu, sigma, log = FALSE) {

  x <- as.numeric(x)

  if (any(!is.finite(x)))
    stop("x must be finite.")

  if (any(x <= 0))
    stop("All observations must be positive.")

  if (any(!is.finite(mu)) || any(mu <= 0))
    stop("mu must be positive.")

  if (any(!is.finite(sigma)) || any(sigma <= 0))
    stop("sigma must be positive.")

  shape <- sigma
  rate <- sigma / mu

  stats::dgamma(x, shape = shape, rate = rate, log = log)
}