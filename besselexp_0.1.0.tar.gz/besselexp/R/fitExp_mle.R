#' MLE for Exponential distribution (scale parameterization)
#' @param x Numeric vector (x > 0).
#' @return A list with elements par, se, logLik, AIC, BIC, convergence.
#' @export
fitExp_mle <- function(x) {

  x <- as.numeric(x)
  if (any(!is.finite(x))) stop("x must be finite.")
  if (any(x <= 0)) stop("All observations must be positive.")
  n <- length(x)

  scale_hat <- mean(x)
  se_hat <- scale_hat / sqrt(n)

  logLik <- sum(stats::dexp(x, rate = 1 / scale_hat, log = TRUE))

  k <- 1L
  AIC <- -2 * logLik + 2 * k
  BIC <- -2 * logLik + log(n) * k

  structure(
    list(par = c(scale = scale_hat),
         se = c(scale = se_hat),
         logLik = logLik, AIC = AIC, BIC = BIC,
         convergence = 0L),
    class = "fitExp_mle"
  )
}