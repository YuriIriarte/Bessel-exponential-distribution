#' Compare BE, Gamma, Weibull and Exponential models
#'
#' @param x Numeric vector of positive observations.
#' @param models Models to compare.
#' @return Data frame with estimates, standard errors, logLik, AIC/BIC and deltas.
#' @export
compare_models <- function(x,
                           models = c("BE","Gamma","Weibull","Exponential")){

  x <- as.numeric(x)
  if (any(!is.finite(x))) stop("x must be finite.")
  if (any(x <= 0)) stop("All observations must be positive.")
  models <- match.arg(models, several.ok = TRUE)

  fits <- list()
  if ("BE" %in% models) fits$BE <- fitBE_mle(x)
  if ("Gamma" %in% models) fits$Gamma <- fitGamma_mle(x)
  if ("Weibull" %in% models) fits$Weibull <- fitWeibull_mle(x)
  if ("Exponential" %in% models) fits$Exponential <- fitExp_mle(x)

  results <- lapply(names(fits), function(m){
    fit <- fits[[m]]
    se <- fit$se
    data.frame(
      model = m,
      parameter = names(fit$par),
      estimate = as.numeric(fit$par),
      std_error = as.numeric(se[names(fit$par)]),
      logLik = rep(fit$logLik, length(fit$par)),
      AIC = rep(fit$AIC, length(fit$par)),
      BIC = rep(fit$BIC, length(fit$par)),
      stringsAsFactors = FALSE
    )
  })

  results <- do.call(rbind, results)

  minAIC <- min(results$AIC)
  minBIC <- min(results$BIC)
  results$DeltaAIC <- results$AIC - minAIC
  results$DeltaBIC <- results$BIC - minBIC

  results <- results[order(results$AIC, results$model, results$parameter),]
  rownames(results) <- NULL
  results
}