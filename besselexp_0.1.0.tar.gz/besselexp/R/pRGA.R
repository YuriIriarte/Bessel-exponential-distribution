#' Distribution function of the reparameterized Gamma distribution
#'
#' Computes the cumulative distribution function of a Gamma distribution
#' parameterized in terms of the mean \eqn{\mu > 0} and a positive
#' shape-related parameter \eqn{\sigma > 0}.
#'
#' Under this parameterization, the usual Gamma parameters are
#' \deqn{
#' \alpha = \sigma, \qquad \lambda = \sigma/\mu,
#' }
#' where \eqn{\alpha} is the shape parameter and \eqn{\lambda} is the rate.
#'
#' Consequently, the mean of the distribution is
#' \deqn{
#' E(Y) = \mu.
#' }
#'
#' @param q Numeric vector of positive quantiles.
#' @param mu Numeric vector of positive means.
#' @param sigma Numeric vector of positive shape-like parameters.
#'
#' @return A numeric vector of cumulative probabilities.
#'
#' @details
#' This reparameterization is commonly used in regression modeling
#' because the parameter \eqn{\mu} corresponds directly to the mean.
#'
#' @examples
#' pRGA(1, mu = 2, sigma = 3)
#' pRGA(c(1, 2, 3), mu = 2, sigma = 3)
#'
#' @seealso \code{\link{dRGA}}, \code{\link{fitRGA_regression}},
#'   \code{\link[stats]{pgamma}}
#' @export
pRGA <- function(q, mu, sigma) {

  q <- as.numeric(q)

  if (any(!is.finite(q)))
    stop("q must be finite.")

  if (any(q <= 0))
    stop("All observations must be positive.")

  if (any(!is.finite(mu)) || any(mu <= 0))
    stop("mu must be positive.")

  if (any(!is.finite(sigma)) || any(sigma <= 0))
    stop("sigma must be positive.")

  shape <- sigma
  rate <- sigma / mu

  stats::pgamma(q, shape = shape, rate = rate)
}