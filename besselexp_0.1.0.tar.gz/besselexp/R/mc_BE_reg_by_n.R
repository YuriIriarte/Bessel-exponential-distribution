#' Monte Carlo BE regression MLE across sample sizes (one scenario)
#'
#' @param ns Integer vector of sample sizes.
#' @inheritParams mc_BE_reg_one_setting
#' @export
mc_BE_reg_by_n <- function(R, ns = c(50, 100, 200, 400),
                           scenario, cov_par,
                           seed = NULL,
                           fit_control = list(n_starts = 15, jitter_sd = 0.05)) {

  ns <- as.integer(ns)
  if (any(!is.finite(ns)) || any(ns <= 0)) stop("ns must be positive integers.")

  if (is.null(seed)) seed <- sample.int(.Machine$integer.max, 1)

  out <- lapply(seq_along(ns), function(j) {
    mc_BE_reg_one_setting(
      R = R,
      n = ns[j],
      scenario = scenario,
      cov_par = cov_par,
      seed = seed + j,
      fit_control = fit_control,
      return_raw = FALSE
    )
  })

  do.call(rbind, out)
}
