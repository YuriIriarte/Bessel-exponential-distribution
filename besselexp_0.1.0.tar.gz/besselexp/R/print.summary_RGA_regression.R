#' Print method for summaries of RGA regression models
#'
#' @param x An object of class \code{"summary.RGA_regression"}.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return The input object is returned invisibly.
#'
#' @method print summary.RGA_regression
#' @export
print.summary.RGA_regression <- function(x, ...) {

  cat("\nSummary of RGA regression model\n")
  cat("---------------------------------\n")
  cat("Log-likelihood:", x$logLik, "\n")
  cat("AIC:", x$AIC, "\n")
  cat("BIC:", x$BIC, "\n")
  cat("Convergence code:", x$convergence, "\n\n")

  print(x$coefficients_table, row.names = FALSE)

  invisible(x)
}