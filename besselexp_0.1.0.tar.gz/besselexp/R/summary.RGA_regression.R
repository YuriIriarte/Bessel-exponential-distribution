#' Summarize a fitted RGA regression model
#'
#' Produces a compact summary of a fitted reparameterized Gamma (RGA)
#' regression model obtained with \code{\link{fitRGA_regression}}.
#'
#' @param object An object of class \code{"RGA_regression"} returned by
#'   \code{\link{fitRGA_regression}}.
#' @param digits Integer specifying the number of decimal places used to round
#'   the reported numerical results. The default is \code{3}.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return An object of class \code{"summary.RGA_regression"} containing a
#' coefficient table, log-likelihood, AIC, BIC, and convergence code.
#'
#' @examples
#' \dontrun{
#' fit <- fitRGA_regression(y, X_mu, X_sigma)
#' summary(fit)
#' }
#'
#' @method summary RGA_regression
#' @export
summary.RGA_regression <- function(object, digits = 3, ...) {

  tab_mu <- data.frame(
    Parameter = names(object$coefficients_mu),
    Estimate = as.numeric(object$coefficients_mu),
    Std.Error = as.numeric(object$se_mu),
    z.value = as.numeric(object$z_mu),
    p.value = as.numeric(object$p_mu),
    stringsAsFactors = FALSE
  )

  tab_sigma <- data.frame(
    Parameter = names(object$coefficients_sigma),
    Estimate = as.numeric(object$coefficients_sigma),
    Std.Error = as.numeric(object$se_sigma),
    z.value = as.numeric(object$z_sigma),
    p.value = as.numeric(object$p_sigma),
    stringsAsFactors = FALSE
  )

  tab <- rbind(tab_mu, tab_sigma)

  tab$Estimate <- round(tab$Estimate, digits)
  tab$Std.Error <- round(tab$Std.Error, digits)
  tab$z.value <- round(tab$z.value, digits)
  tab$p.value <- round(tab$p.value, digits)

  out <- list(
    coefficients_table = tab,
    logLik = round(object$logLik, digits),
    AIC = round(object$AIC, digits),
    BIC = round(object$BIC, digits),
    convergence = object$convergence
  )

  class(out) <- "summary.RGA_regression"
  out
}