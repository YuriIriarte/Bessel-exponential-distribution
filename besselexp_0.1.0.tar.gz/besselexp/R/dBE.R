#' Density of the Bessel-Exponential (BE) distribution
#'
#' @param x Numeric vector (x > 0).
#' @param mu Mode parameter (mu > 0).
#' @param sigma Scale parameter (sigma > 0).
#' @param log Logical; if TRUE, return log-density.
#'
#' @return Numeric vector.
#' @export
dBE <- function(x, mu, sigma, log = FALSE) {
  x <- as.numeric(x)
  if (any(!is.finite(x))) stop("x must be finite.")
  if (any(x <= 0)) stop("All observations must be positive.")

  a <- mu
  b <- sigma/(2*mu^2)

  rmutil::dginvgauss(x, m = a, s = b, f = 1, log = log)
}
