#' Distribution function of the BE distribution
#'
#' @param q Numeric vector (q > 0).
#' @param mu Mode parameter (mu > 0).
#' @param sigma Scale parameter (sigma > 0).
#'
#' @return Numeric vector of probabilities.
#' @export
pBE <- function(q, mu, sigma) {
  q <- as.numeric(q)
  if (any(!is.finite(q))) stop("q must be finite.")
  if (any(q <= 0)) stop("All observations must be positive.")

  a <- mu
  b <- sigma/(2*mu^2)

  rmutil::pginvgauss(q, m = a, s = b, f = 1)
}
