#' Residuals for RGA regression models
#'
#' Computes randomized quantile residuals and generalized Cox-Snell
#' residuals for a fitted reparameterized Gamma regression model.
#'
#' @param object An object of class \code{"RGA_regression"}.
#' @param type Type of residuals to be returned. One of
#'   \code{"quantile"}, \code{"coxsnell"}, or \code{"all"}.
#' @param y Optional response vector. If omitted, the response stored in
#'   \code{object$y} is used.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return If \code{type = "quantile"}, a numeric vector of randomized quantile
#' residuals. If \code{type = "coxsnell"}, a numeric vector of generalized
#' Cox-Snell residuals. If \code{type = "all"}, a list with components
#' \code{quantile} and \code{coxsnell}.
#'
#' @examples
#' \dontrun{
#' fit <- fitRGA_regression(y, X_mu, X_sigma)
#' residuals(fit, type = "quantile")
#' residuals(fit, type = "coxsnell")
#' residuals(fit, type = "all")
#' }
#'
#' @method residuals RGA_regression
#' @export
residuals.RGA_regression <- function(object,
                                     type = c("quantile", "coxsnell", "all"),
                                     y = NULL,
                                     ...) {

  type <- match.arg(type)

  if (is.null(y)) {
    if (!is.null(object$y)) {
      y <- object$y
    } else {
      stop("Response vector 'y' must be supplied, or stored in the fitted object.")
    }
  }

  y <- as.numeric(y)

  mu_hat <- object$fitted_mu
  sigma_hat <- object$fitted_sigma

  Fy <- pRGA(y, mu = mu_hat, sigma = sigma_hat)

  eps <- .Machine$double.eps
  Fy <- pmin(pmax(Fy, eps), 1 - eps)

  r_quantile <- stats::qnorm(Fy)
  r_coxsnell <- -log(1 - Fy)

  if (type == "quantile") return(r_quantile)
  if (type == "coxsnell") return(r_coxsnell)

  list(
    quantile = r_quantile,
    coxsnell = r_coxsnell
  )
}