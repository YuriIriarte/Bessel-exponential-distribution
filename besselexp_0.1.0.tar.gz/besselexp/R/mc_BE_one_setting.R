# ============================================================
# Monte Carlo: one BE setting (DGP = BE), no covariates
# ============================================================

#' Monte Carlo performance for BE MLE (one setting)
#'
#' @param R Number of Monte Carlo replicates.
#' @param n Sample size.
#' @param mu_true True mode parameter.
#' @param sigma_true True scale parameter.
#' @param seed Optional integer seed.
#' @param alpha Significance level for Wald CI (default 0.05 => 95% CI).
#' @param fit_control List passed to fitBE_mle (e.g., list(n_starts=15)).
#' @param return_raw Logical; if TRUE, returns replicate-level results too.
#'
#' @return If return_raw=FALSE: data.frame summary.
#'         If return_raw=TRUE: list(summary=..., raw=data.frame).
#' @export
mc_BE_one_setting <- function(R, n, mu_true, sigma_true,
                              seed = NULL, alpha = 0.05,
                              fit_control = list(),
                              return_raw = FALSE) {

  R <- as.integer(R)
  n <- as.integer(n)
  if (!is.null(seed)) set.seed(as.integer(seed))

  if (!is.finite(R) || R <= 0) stop("R must be a positive integer.")
  if (!is.finite(n) || n <= 0) stop("n must be a positive integer.")
  if (!is.finite(mu_true) || mu_true <= 0) stop("mu_true must be > 0.")
  if (!is.finite(sigma_true) || sigma_true <= 0) stop("sigma_true must be > 0.")
  if (!is.finite(alpha) || alpha <= 0 || alpha >= 1) stop("alpha must be in (0,1).")

  z <- stats::qnorm(1 - alpha/2)

  mu_hat <- rep(NA_real_, R)
  sig_hat <- rep(NA_real_, R)
  se_mu <- rep(NA_real_, R)
  se_sig <- rep(NA_real_, R)
  conv <- rep(0L, R)

  fit_call <- function(x) {
    args <- c(list(x = x), fit_control)
    do.call(fitBE_mle, args)
  }

  for (r in seq_len(R)) {

    x <- rBE(n = n, mu = mu_true, sigma = sigma_true)

    fit <- tryCatch(fit_call(x), error = function(e) NULL)
    if (is.null(fit)) {
      conv[r] <- 0L
      next
    }

    ok <- isTRUE(fit$convergence == 0) &&
      all(is.finite(fit$par[c("mu","sigma")]))

    if (!ok) {
      conv[r] <- 0L
      next
    }

    conv[r] <- 1L
    mu_hat[r]  <- unname(fit$par["mu"])
    sig_hat[r] <- unname(fit$par["sigma"])

    if (!is.null(fit$se)) {
      se_mu[r]  <- unname(fit$se["mu"])
      se_sig[r] <- unname(fit$se["sigma"])
    }
  }

  idx <- which(conv == 1L)

  Bias_mu <- mean(mu_hat[idx] - mu_true)
  RMSE_mu <- sqrt(mean((mu_hat[idx] - mu_true)^2))

  Bias_sig <- mean(sig_hat[idx] - sigma_true)
  RMSE_sig <- sqrt(mean((sig_hat[idx] - sigma_true)^2))

  cov_mu_idx <- idx[is.finite(se_mu[idx]) & se_mu[idx] > 0]
  cov_sig_idx <- idx[is.finite(se_sig[idx]) & se_sig[idx] > 0]

  Cov95_mu <- if (length(cov_mu_idx) == 0) NA_real_ else {
    mean((mu_true >= mu_hat[cov_mu_idx] - z * se_mu[cov_mu_idx]) &
           (mu_true <= mu_hat[cov_mu_idx] + z * se_mu[cov_mu_idx]))
  }

  Cov95_sigma <- if (length(cov_sig_idx) == 0) NA_real_ else {
    mean((sigma_true >= sig_hat[cov_sig_idx] - z * se_sig[cov_sig_idx]) &
           (sigma_true <= sig_hat[cov_sig_idx] + z * se_sig[cov_sig_idx]))
  }

  summary_df <- data.frame(
    R = R,
    n = n,
    mu_true = mu_true,
    sigma_true = sigma_true,
    Bias_mu = Bias_mu,
    RMSE_mu = RMSE_mu,
    Cov95_mu = Cov95_mu,
    Bias_sigma = Bias_sig,
    RMSE_sigma = RMSE_sig,
    Cov95_sigma = Cov95_sigma,
    Conv_pct = 100 * mean(conv),
    n_conv = length(idx),
    n_cov_mu = length(cov_mu_idx),
    n_cov_sigma = length(cov_sig_idx)
  )

  if (!return_raw) return(summary_df)

  raw_df <- data.frame(
    rep = seq_len(R),
    conv = conv,
    mu_hat = mu_hat,
    sigma_hat = sig_hat,
    se_mu = se_mu,
    se_sigma = se_sig
  )

  list(summary = summary_df, raw = raw_df)
}