#' Quantile function of the BE distribution
#'
#' @param p Numeric vector of probabilities in (0,1).
#' @param mu Mode parameter (mu > 0).
#' @param sigma Scale parameter (sigma > 0).
#'
#' @return Numeric vector.
#' @export
qBE <- function(p, mu, sigma) {
  p <- as.numeric(p)
  if (any(!is.finite(p))) stop("p must be finite.")
  if (any(p <= 0 | p >= 1)) stop("p must be in (0,1).")

  a <- mu
  b <- sigma/(2*mu^2)

  rmutil::qginvgauss(p, m = a, s = b, f = 1)
}
