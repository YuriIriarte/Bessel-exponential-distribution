#' Print method for RGA regression models
#'
#' @param x An object of class \code{"RGA_regression"}.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return The input object is returned invisibly.
#'
#' @method print RGA_regression
#' @export
print.RGA_regression <- function(x, ...) {

  cat("\nReparameterized Gamma regression model\n")
  cat("--------------------------------------\n")
  cat("Number of observations:", length(x$y), "\n")
  cat("Mean submodel coefficients:", length(x$coefficients_mu), "\n")
  cat("Scale submodel coefficients:", length(x$coefficients_sigma), "\n")
  cat("Log-likelihood:", round(x$logLik, 3), "\n")
  cat("AIC:", round(x$AIC, 3), "\n")
  cat("BIC:", round(x$BIC, 3), "\n")
  cat("Convergence code:", x$convergence, "\n")

  invisible(x)
}