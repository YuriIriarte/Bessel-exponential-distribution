#' Random generation from the BE distribution
#'
#' @param n Sample size (positive integer).
#' @param mu Mode parameter (mu > 0).
#' @param sigma Scale parameter (sigma > 0).
#'
#' @return Numeric vector.
#' @export
rBE <- function(n, mu, sigma) {
  n <- as.integer(n)
  if (!is.finite(n) || n <= 0) stop("n must be a positive integer.")

  a <- mu
  b <- sigma/(2*mu^2)

  rmutil::rginvgauss(n, m = a, s = b, f = 1)
}