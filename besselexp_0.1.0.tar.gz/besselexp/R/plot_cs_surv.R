#' Plot generalized Cox-Snell residual survival curve
#'
#' Plots the empirical survival function of generalized Cox-Snell residuals,
#' based on the Kaplan-Meier estimator, together with the theoretical survival
#' function of an Exponential(1) distribution, i.e., \eqn{S(t) = \exp(-t)}.
#' Confidence bands for the empirical survival curve are also displayed.
#'
#' @param resid_cs A numeric vector of generalized Cox-Snell residuals.
#' Non-finite values are automatically removed.
#' @param titulo A character string specifying the plot title.
#' @param color_emp A character string specifying the color used for the
#' empirical survival curve. Default is `"steelblue4"`.
#' @param color_theo A character string specifying the color used for the
#' theoretical survival curve. Default is `"black"`.
#' @param ribbon_fill A character string specifying the fill color for the
#' confidence band. Default is `"skyblue"`.
#' @param conf_type A character string specifying the type of confidence interval
#' used in [survival::survfit()]. Default is `"log-log"`.
#'
#' @return A `ggplot2` object.
#'
#' @details
#' Under a correctly specified model, generalized Cox-Snell residuals should
#' approximately follow an Exponential distribution with mean 1. Therefore, the
#' empirical survival curve is expected to be close to the theoretical curve
#' \eqn{\exp(-t)}.
#'
#' @examples
#' \dontrun{
#' set.seed(123)
#' resid <- rexp(100)
#' plot_cs_surv(resid, titulo = "Cox-Snell residuals")
#' }
#'
#' @importFrom survival Surv survfit
#' @importFrom ggplot2 ggplot geom_ribbon geom_step geom_point geom_line
#' @importFrom ggplot2 aes scale_color_manual labs coord_cartesian
#' @importFrom ggplot2 theme_minimal theme element_text element_rect
#' @importFrom scales alpha
#' @export
plot_cs_surv <- function(resid_cs, titulo, color_emp = "steelblue4",
                         color_theo = "black", ribbon_fill = "skyblue",
                         conf_type = "log-log") {
  resid_cs <- resid_cs[is.finite(resid_cs)]

  if (!is.numeric(resid_cs)) {
    stop("'resid_cs' must be a numeric vector.")
  }

  if (length(resid_cs) == 0) {
    stop("'resid_cs' has no finite values after removing non-finite entries.")
  }

  if (any(resid_cs < 0)) {
    stop("'resid_cs' must contain non-negative values.")
  }

  n <- length(resid_cs)

  sf <- survival::survfit(
    survival::Surv(time = resid_cs, event = rep(1, n)) ~ 1,
    conf.type = conf_type
  )

  df_km <- data.frame(
    time  = c(0, sf$time),
    surv  = c(1, sf$surv),
    lower = c(1, sf$lower),
    upper = c(1, sf$upper)
  )

  tmax <- max(resid_cs, na.rm = TRUE)
  tt   <- seq(0, tmax, length.out = 400)
  df_th <- data.frame(time = tt, surv = exp(-tt))

  ggplot2::ggplot() +
    ggplot2::geom_ribbon(
      data = df_km,
      ggplot2::aes(x = time, ymin = lower, ymax = upper),
      fill = ribbon_fill, alpha = 0.40
    ) +
    ggplot2::geom_step(
      data = df_km,
      ggplot2::aes(x = time, y = surv, color = "Empirical"),
      direction = "hv", linewidth = 0.9
    ) +
    ggplot2::geom_point(
      data = subset(df_km, time > 0),
      ggplot2::aes(x = time, y = surv, color = "Empirical"),
      shape = 4, size = 1, stroke = 0.7
    ) +
    ggplot2::geom_line(
      data = df_th,
      ggplot2::aes(x = time, y = surv, color = "Theoretical"),
      linewidth = 0.9
    ) +
    ggplot2::scale_color_manual(
      name = NULL,
      values = c("Empirical" = color_emp, "Theoretical" = color_theo)
    ) +
    ggplot2::labs(
      title = titulo,
      x = "Generalized Cox-Snell residuals",
      y = "Survival function"
    ) +
    ggplot2::coord_cartesian(xlim = c(0, tmax)) +
    ggplot2::theme_minimal() +
    ggplot2::theme(
      axis.title = ggplot2::element_text(size = 15),
      axis.text = ggplot2::element_text(size = 12),
      panel.border = ggplot2::element_rect(
        color = "black", fill = NA, linewidth = 1
      ),
      legend.position = c(0.8, 0.81),
      legend.background = ggplot2::element_rect(
        fill = scales::alpha("white", 0.5)
      )
    )
}