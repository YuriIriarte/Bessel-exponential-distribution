#' Print method for BE regression models
#'
#' @param x An object of class \code{"BE_regression"}.
#' @param ... Further arguments passed to or from other methods.
#'
#' @return The input object is returned invisibly.
#'
#' @method print BE_regression
#' @export
print.BE_regression <- function(x, ...) {

  cat("\nBessel-Exponential regression model\n")
  cat("-----------------------------------\n")
  cat("Number of observations:", length(x$y), "\n")
  cat("Mode submodel coefficients:", length(x$coefficients_mu), "\n")
  cat("Scale submodel coefficients:", length(x$coefficients_sigma), "\n")
  cat("Log-likelihood:", round(x$logLik, 3), "\n")
  cat("AIC:", round(x$AIC, 3), "\n")
  cat("BIC:", round(x$BIC, 3), "\n")
  cat("Convergence code:", x$convergence, "\n")

  invisible(x)
}